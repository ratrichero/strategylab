// @ts-nocheck
/* eslint-disable */
import { useEffect, useState } from "react";
import { Card, CardHeader } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { Select } from "../components/ui/Select";
import { Settings as SettingsIcon, Save, RotateCcw, Loader2, CheckCircle, AlertCircle, Radar, ShieldCheck, Server, Layers, Filter, Crosshair, Activity, Plug, KeyRound, Palette } from "lucide-react";
import { config, tradingMode as tmApi, strategies as stratsApi, otf as otfApi, prefill as prefillApi, ml } from "../services/api";
import { useAppStore } from "../store/appStore";
import toast from "react-hot-toast";

const API = "/api";
async function loadConfig() { const r = await fetch(`${API}/app-config`); return r.json(); }
async function saveConfigKeys(u) { await fetch(`${API}/app-config`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(u) }); }
function Field({ label, hint, children }) { return (<div><label className="block text-sm font-medium text-slate-300 mb-1.5">{label}</label>{children}{hint && <p className="text-xs text-slate-500 mt-1">{hint}</p>}</div>); }
function NumField({ label, value, onChange, hint, step }) { return (<Field label={label} hint={hint}><input type="number" step={step || "any"} value={value} onChange={e => onChange(e.target.value)} className="w-full bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500" /></Field>); }
function TextField({ label, value, onChange, hint, type = "text", placeholder = "" }) { return (<Field label={label} hint={hint}><input type={type} value={value} placeholder={placeholder} onChange={e => onChange(e.target.value)} className="w-full bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500" /></Field>); }
function BoolField({ label, value, onChange, hint }) { return (<Field label={label} hint={hint}><div className="flex items-center gap-3"><button onClick={() => onChange(!value)} className={`relative w-14 h-7 rounded-full transition-colors flex-shrink-0 ${value ? "bg-indigo-600" : "bg-slate-700"}`}><div className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow transition-transform ${value ? "translate-x-7" : "translate-x-1"}`} /></button><span className={`text-sm font-medium ${value ? "text-emerald-400" : "text-slate-500"}`}>{value ? "Enabled" : "Disabled"}</span></div></Field>); }
function SaveRow({ saving, saved, onSave, onCancel }) { return (<div className="flex items-center gap-3 mt-6 pt-4 border-t border-slate-700"><Button variant="primary" icon={saving ? undefined : <Save className="w-4 h-4" />} loading={saving} onClick={onSave}>Apply</Button>{onCancel && <Button variant="ghost" icon={<RotateCcw className="w-4 h-4" />} onClick={onCancel}>Cancel</Button>}{saved && <span className="flex items-center gap-1 text-sm text-emerald-400"><CheckCircle className="w-4 h-4" /> Saved</span>}</div>); }

// Multi-select row with All toggle for Identity section
function MultiRow({ label, allItems, selected, onToggle, onSetAll }) {
  const isAllSelected = allItems.length > 0 && allItems.every(i => (selected || []).includes(i));
  return (
    <div className="flex gap-2 items-center flex-wrap">
      <span className="text-xs text-slate-400 w-24 flex-shrink-0">{label}</span>
      <button onClick={() => onSetAll(isAllSelected ? [] : [...allItems])} className={`px-2 py-1 rounded text-xs font-medium border transition-colors ${isAllSelected ? "border-indigo-500 bg-indigo-600/30 text-indigo-300" : "border-slate-600 bg-slate-800 text-slate-500 hover:border-slate-500"}`}>All</button>
      {allItems.map(item => (
        <button key={item} onClick={() => onToggle(item)} className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${(selected || []).includes(item) ? "bg-blue-600 text-white" : "bg-slate-700 text-slate-400 hover:bg-slate-600"}`}>{item}</button>
      ))}
      {(selected || []).length === 0 && <span className="text-xs text-slate-500 italic">(All allowed)</span>}
    </div>
  );
}

const TABS = [
  { id: "scan", label: "Scan", icon: Radar },
  { id: "signals", label: "Signal", icon: Crosshair },
  { id: "filter", label: "Trade Filter", icon: Filter },
  { id: "prefill", label: "Pre-Fill", icon: ShieldCheck },
  { id: "strats", label: "Strategies", icon: Layers },
  { id: "live", label: "Live Trading", icon: Activity },
  { id: "system", label: "System", icon: Server },
  { id: "conn", label: "Connection", icon: Plug },
  { id: "apikey", label: "API Keys", icon: KeyRound },
];

export function SettingsPage() {
  const [tab, setTab] = useState("scan"); const [loading, setLoading] = useState(true); const [error, setError] = useState(""); const [orig, setOrig] = useState({});
  // Signal Config
  const [scoreThreshold, setScoreThreshold] = useState(""); const [bodyRatio, setBodyRatio] = useState(""); const [volMult, setVolMult] = useState(""); const [atrMin, setAtrMin] = useState(""); const [cooldown, setCooldown] = useState(""); const [aiThreshold, setAiThreshold] = useState(""); const [mtfEnabled, setMtfEnabled] = useState(false);
  const [derivBias15m, setDerivBias15m] = useState(""); const [derivBias1h, setDerivBias1h] = useState(""); const [derivBias4h, setDerivBias4h] = useState(""); const [derivPreBuffer, setDerivPreBuffer] = useState("");
  const [riskSl15m, setRiskSl15m] = useState(""); const [riskTp15m, setRiskTp15m] = useState(""); const [riskSl1h, setRiskSl1h] = useState(""); const [riskTp1h, setRiskTp1h] = useState(""); const [riskSl4h, setRiskSl4h] = useState(""); const [riskTp4h, setRiskTp4h] = useState("");
  const [pendEnabled, setPendEnabled] = useState(true);
  const [pendAtr15m, setPendAtr15m] = useState(""); const [pendAtr1h, setPendAtr1h] = useState(""); const [pendAtr4h, setPendAtr4h] = useState("");
  const [pendExp15m, setPendExp15m] = useState(""); const [pendExp1h, setPendExp1h] = useState(""); const [pendExp4h, setPendExp4h] = useState("");
  const [s1, setS1] = useState(false); const [sv1, setSv1] = useState(false);
  // Scan Config
  const [engVer, setEngVer] = useState(""); const [topLimit, setTopLimit] = useState(""); const [maxOpenTrades, setMaxOpenTrades] = useState('50'); const [timeframe, setTimeframe] = useState("15m"); const [scheduler, setScheduler] = useState(false); const [monitor, setMonitor] = useState(false);
  const [s2, setS2] = useState(false); const [sv2, setSv2] = useState(false);
  // Trade Filter
  const [otfConfig, setOtfConfig] = useState(null); const [otfStatus, setOtfStatus] = useState(null); const [sOtf, setSOtf] = useState(false); const [svOtf, setSvOtf] = useState(false);
  // Pre-Fill
  const [pfConfig, setPfConfig] = useState(null); const [sPf, setSPf] = useState(false); const [svPf, setSvPf] = useState(false);
  // Strategies
  const [stratsList, setStratsList] = useState([]); const [sSt, setSSt] = useState(false); const [svSt, setSvSt] = useState(false);
  // Live Trading
  const [limitEnabled, setLimitEnabled] = useState(true);
  const [limitRp15m, setLimitRp15m] = useState(""); const [limitRp1h, setLimitRp1h] = useState(""); const [limitRp4h, setLimitRp4h] = useState("");
  const [sLt, setSLt] = useState(false); const [svLt, setSvLt] = useState(false);
  // System
  const [modeInfo, setModeInfo] = useState(null); const [feedInfo, setFeedInfo] = useState(null); const [mlInfo, setMlInfo] = useState(null); const [retraining, setRetraining] = useState(false); const [retainResult, setRetainResult] = useState(null);
  const { theme: storeTheme, setTheme: setStoreTheme } = useAppStore();
  // Connection
  const [connOverride, setConnOverride] = useState(false);
  const [connDb, setConnDb] = useState(""); const [connBnKey, setConnBnKey] = useState(""); const [connBnSecret, setConnBnSecret] = useState(""); const [connTgToken, setConnTgToken] = useState(""); const [connGroq, setConnGroq] = useState(""); const [connGemini, setConnGemini] = useState("");
  const [sConn, setSConn] = useState(false); const [svConn, setSvConn] = useState(false);
  // API Keys
  const [dashApiKey, setDashApiKey] = useState(""); const [sKey, setSKey] = useState(false); const [svKey, setSvKey] = useState(false);

  const applyConfig = (c) => {
    setScoreThreshold(c["SCORE_THRESHOLD"]||""); setBodyRatio(c["BODY_RATIO_THRESHOLD"]||""); setVolMult(c["VOLUME_MULTIPLIER"]||""); setAtrMin(c["ATR_RATIO_MIN"]||""); setCooldown(c["COOLDOWN_HOURS"]||""); setAiThreshold(c["AI_THRESHOLD"]||""); setMtfEnabled(c["MTF_ENABLED"]?.toLowerCase()==="true");
    try { const d = JSON.parse(c["DERIVATIVE_CONFIG"]||"{}"); setDerivBias15m(String(d.bias_scale?.["15m"] ?? "")); setDerivBias1h(String(d.bias_scale?.["1h"] ?? "")); setDerivBias4h(String(d.bias_scale?.["4h"] ?? "")); setDerivPreBuffer(String(d.pre_buffer ?? "")); } catch { setDerivBias15m(""); setDerivBias1h(""); setDerivBias4h(""); setDerivPreBuffer(""); }
    try { const r = JSON.parse(c["RISK_CONFIG"]||"{}"); setRiskSl15m(String(r["15m"]?.sl_mult ?? "")); setRiskTp15m(String(r["15m"]?.tp_mult ?? "")); setRiskSl1h(String(r["1h"]?.sl_mult ?? "")); setRiskTp1h(String(r["1h"]?.tp_mult ?? "")); setRiskSl4h(String(r["4h"]?.sl_mult ?? "")); setRiskTp4h(String(r["4h"]?.tp_mult ?? "")); } catch { setRiskSl15m(""); setRiskTp15m(""); setRiskSl1h(""); setRiskTp1h(""); setRiskSl4h(""); setRiskTp4h(""); }
    try { const p = JSON.parse(c["PENDING_CONFIG"]||"{}"); setPendEnabled(p.enabled !== false); setPendAtr15m(String(p.atr_entry_multiplier?.["15m"] ?? "")); setPendAtr1h(String(p.atr_entry_multiplier?.["1h"] ?? "")); setPendAtr4h(String(p.atr_entry_multiplier?.["4h"] ?? "")); setPendExp15m(String(p.expire_hours?.["15m"] ?? "")); setPendExp1h(String(p.expire_hours?.["1h"] ?? "")); setPendExp4h(String(p.expire_hours?.["4h"] ?? "")); } catch { setPendEnabled(true); setPendAtr15m(""); setPendAtr1h(""); setPendAtr4h(""); setPendExp15m(""); setPendExp1h(""); setPendExp4h(""); }
    try { const l = JSON.parse(c["LIMIT_ORDER_CONFIG"]||"{}"); setLimitEnabled(l.enabled !== false); setLimitRp15m(String(l.entry_reprice_pct?.["15m"] ?? "")); setLimitRp1h(String(l.entry_reprice_pct?.["1h"] ?? "")); setLimitRp4h(String(l.entry_reprice_pct?.["4h"] ?? "")); } catch { setLimitEnabled(true); setLimitRp15m(""); setLimitRp1h(""); setLimitRp4h(""); }
    setEngVer(c["ENGINE_VERSION"]||""); setTopLimit(c["TOP_LIMIT"]||""); setTimeframe(c["TIMEFRAME"]||"15m"); setScheduler(c["ENABLE_SCHEDULER"]?.toLowerCase()==="true"); setMonitor(c["ENABLE_MONITOR"]?.toLowerCase()==="true"); setMaxOpenTrades(c['MAX_OPEN_TRADES']||'50');
    if (c["THEME"]) setStoreTheme(c["THEME"]);
    setConnOverride(c["CONNECTION_OVERRIDE"]?.toLowerCase() === "true");
    setConnDb(c["DATABASE_URL"]||""); setConnBnKey(c["BINANCE_API_KEY"]||""); setConnBnSecret(c["BINANCE_API_SECRET"]||""); setConnTgToken(c["TELEGRAM_BOT_TOKEN"]||""); setConnGroq(c["GROQ_API_KEY"]||""); setConnGemini(c["GEMINI_API_KEY"]||"");
    setDashApiKey(c["DASHBOARD_API_KEY"]||"");
  };

  const buildDerivJson = () => JSON.stringify({ bias_scale: { "15m": parseFloat(derivBias15m) || 0, "1h": parseFloat(derivBias1h) || 0, "4h": parseFloat(derivBias4h) || 0 }, pre_buffer: parseFloat(derivPreBuffer) || 0 });
  const buildRiskJson = () => JSON.stringify({ "15m": { sl_mult: parseFloat(riskSl15m) || 0, tp_mult: parseFloat(riskTp15m) || 0 }, "1h": { sl_mult: parseFloat(riskSl1h) || 0, tp_mult: parseFloat(riskTp1h) || 0 }, "4h": { sl_mult: parseFloat(riskSl4h) || 0, tp_mult: parseFloat(riskTp4h) || 0 } });
  const buildPendJson = () => JSON.stringify({ enabled: pendEnabled, atr_entry_multiplier: { "15m": parseFloat(pendAtr15m) || 0, "1h": parseFloat(pendAtr1h) || 0, "4h": parseFloat(pendAtr4h) || 0 }, expire_hours: { "15m": parseFloat(pendExp15m) || 0, "1h": parseFloat(pendExp1h) || 0, "4h": parseFloat(pendExp4h) || 0 } });
  const buildLimitJson = () => JSON.stringify({ enabled: limitEnabled, entry_reprice_pct: { "15m": parseFloat(limitRp15m) || 0, "1h": parseFloat(limitRp1h) || 0, "4h": parseFloat(limitRp4h) || 0 } });

  useEffect(() => { (async () => { setLoading(true); try { const [cfg, otf, pf, strats, mode, feed, mlEval] = await Promise.all([loadConfig(), otfApi.get().catch(() => ({ enabled: false })), prefillApi.get().catch(() => ({ enabled: true })), stratsApi.list().catch(() => null), tmApi.get().catch(() => null), fetch("/api/price-feed/status").then(r => r.json()).catch(() => null), ml.evaluate(30).catch(() => null)]); setOrig(cfg); applyConfig(cfg); setOtfConfig(otf); setPfConfig(pf);
    const ALL_STRATS = ["candlestick","breakout","mean_reversion","pullback","trend_following"];
    let allS = strats?.all || ALL_STRATS; let activeS = strats?.active || [];
    if (!activeS.length && cfg["ACTIVE_STRATEGIES"]) { activeS = cfg["ACTIVE_STRATEGIES"].split(",").map(s => s.trim()).filter(Boolean); }
    setStratsList(allS.map(name => ({ name, active: activeS.includes(name) })));
    setModeInfo(mode); setFeedInfo(feed); setMlInfo(mlEval); const s = await otfApi.status().catch(() => null); setOtfStatus(s); } catch (e) { setError(e.message); } finally { setLoading(false); } })(); }, []);

  const saveSignalConfig = async () => { setS1(true); setSv1(false); setError(""); try { await saveConfigKeys({ SCORE_THRESHOLD: scoreThreshold, BODY_RATIO_THRESHOLD: bodyRatio, VOLUME_MULTIPLIER: volMult, ATR_RATIO_MIN: atrMin, COOLDOWN_HOURS: cooldown, AI_THRESHOLD: aiThreshold, MTF_ENABLED: String(mtfEnabled), DERIVATIVE_CONFIG: buildDerivJson(), RISK_CONFIG: buildRiskJson(), PENDING_CONFIG: buildPendJson() }); setSv1(true); setTimeout(() => setSv1(false), 3000); toast.success("Signal config saved"); } catch (e) { setError(e.message); toast.error(e.message); } finally { setS1(false); } };
  const saveScanConfig = async () => { setS2(true); setSv2(false); setError(""); try { await saveConfigKeys({ ENGINE_VERSION: engVer, TOP_LIMIT: topLimit, TIMEFRAME: timeframe, ENABLE_SCHEDULER: String(scheduler), ENABLE_MONITOR: String(monitor), MAX_OPEN_TRADES: maxOpenTrades }); setSv2(true); setTimeout(() => setSv2(false), 3000); toast.success("Scan config saved"); } catch (e) { setError(e.message); toast.error(e.message); } finally { setS2(false); } };
  const updOtf = (path, value) => { setOtfConfig(prev => { if (!prev) return prev; const next = JSON.parse(JSON.stringify(prev)); const keys = path.split("."); let obj = next; for (let i = 0; i < keys.length - 1; i++) { if (!obj[keys[i]] || typeof obj[keys[i]] !== "object") obj[keys[i]] = {}; obj = obj[keys[i]]; } obj[keys[keys.length - 1]] = value; return next; }); };
  const togOtfArr = (path, val) => { setOtfConfig(prev => { if (!prev) return prev; const next = JSON.parse(JSON.stringify(prev)); const keys = path.split("."); const lastKey = keys[keys.length - 1]; let parent = next; for (let i = 0; i < keys.length - 1; i++) { if (!parent[keys[i]] || typeof parent[keys[i]] !== "object") parent[keys[i]] = {}; parent = parent[keys[i]]; } if (!Array.isArray(parent[lastKey])) parent[lastKey] = []; const arr = parent[lastKey]; const idx = arr.indexOf(val); if (idx >= 0) arr.splice(idx, 1); else arr.push(val); return next; }); };
  // OTF save: route through app_config to avoid utc_now() backend bug
  const saveOtf = async () => { setSOtf(true); setSvOtf(false); try { await saveConfigKeys({ OPEN_TRADE_FILTER: JSON.stringify(otfConfig) }); setSvOtf(true); setTimeout(() => setSvOtf(false), 3000); toast.success("Trade Filter saved"); } catch (e) { toast.error(e.message); } finally { setSOtf(false); } };
  const updPf = (path, value) => { setPfConfig(prev => { if (!prev) return prev; const next = JSON.parse(JSON.stringify(prev)); const keys = path.split("."); let obj = next; for (let i = 0; i < keys.length - 1; i++) { if (!obj[keys[i]] || typeof obj[keys[i]] !== "object") obj[keys[i]] = {}; obj = obj[keys[i]]; } obj[keys[keys.length - 1]] = value; return next; }); };
  const savePf = async () => { setSPf(true); setSvPf(false); try { await prefillApi.save(pfConfig); setSvPf(true); setTimeout(() => setSvPf(false), 3000); toast.success("Pre-Fill Config saved"); } catch (e) { toast.error(e.message); } finally { setSPf(false); } };
  const toggleStrat = (name) => { setStratsList(prev => prev.map(s => s.name === name ? { ...s, active: !s.active } : s)); };
  const saveStrats = async () => { setSSt(true); setSvSt(false); try { const active = stratsList.filter(s => s.active).map(s => s.name); if (!active.length) active.push("candlestick"); await saveConfigKeys({ ACTIVE_STRATEGIES: active.join(",") }); setSvSt(true); setTimeout(() => setSvSt(false), 3000); toast.success("Strategies saved"); } catch (e) { toast.error(e.message); } finally { setSSt(false); } };
  const saveLiveTrading = async () => { setSLt(true); setSvLt(false); try { await saveConfigKeys({ LIMIT_ORDER_CONFIG: buildLimitJson() }); setSvLt(true); setTimeout(() => setSvLt(false), 3000); toast.success("Live Trading config saved"); } catch (e) { toast.error(e.message); } finally { setSLt(false); } };
  const switchMode = async (mode) => { if (mode === "LIVE" && !confirm("⚠️ LIVE mode uses REAL MONEY. Confirm?")) return; try { const r = await tmApi.set(mode); setModeInfo(r); toast.success(`Mode → ${mode}`); } catch (e) { toast.error(e.message); } };
  const retrain = async () => { setRetraining(true); setRetainResult(null); try { const r = await ml.retrain(false); setRetainResult(r); } catch (e) { toast.error(e.message); } finally { setRetraining(false); } };
  const saveConn = async () => { setSConn(true); setSvConn(false); try { const u = { CONNECTION_OVERRIDE: String(connOverride) }; if (connDb) u["DATABASE_URL"] = connDb; if (connBnKey) u["BINANCE_API_KEY"] = connBnKey; if (connBnSecret) u["BINANCE_API_SECRET"] = connBnSecret; if (connTgToken) u["TELEGRAM_BOT_TOKEN"] = connTgToken; if (connGroq) u["GROQ_API_KEY"] = connGroq; if (connGemini) u["GEMINI_API_KEY"] = connGemini; await saveConfigKeys(u); setSvConn(true); setTimeout(() => setSvConn(false), 3000); toast.success("Connection saved"); } catch (e) { toast.error(e.message); } finally { setSConn(false); } };
  const saveApiKey = async () => { setSKey(true); setSvKey(false); try { await saveConfigKeys({ DASHBOARD_API_KEY: dashApiKey }); setSvKey(true); setTimeout(() => setSvKey(false), 3000); toast.success("API Key saved"); } catch (e) { toast.error(e.message); } finally { setSKey(false); } };
  const saveTheme = async (t) => { setStoreTheme(t); try { await saveConfigKeys({ THEME: t }); toast.success(`Theme → ${t}`); } catch (e) { toast.error(e.message); } };

  if (loading) return (<div className="flex items-center justify-center h-96"><div className="text-center"><Loader2 className="w-8 h-8 animate-spin text-indigo-500 mx-auto mb-4" /><p className="text-slate-400">Loading...</p></div></div>);

  const otf = otfConfig || {};
  const pf = pfConfig || {};

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold text-white flex items-center gap-3"><SettingsIcon className="w-7 h-7 text-indigo-400" /> Settings</h2><p className="text-slate-400 mt-1">Runtime configuration from database (app_config)</p></div>
      </div>
      {error && (<div className="flex items-center gap-2 p-4 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm"><AlertCircle className="w-5 h-5 flex-shrink-0" />{error}</div>)}
      <div className="flex gap-1.5 bg-slate-800/50 p-1.5 rounded-xl overflow-x-auto">{TABS.map(t => (<button key={t.id} onClick={() => setTab(t.id)} className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium whitespace-nowrap rounded-lg transition-all ${tab === t.id ? "bg-indigo-600 text-white shadow-lg shadow-indigo-500/20" : "text-slate-400 hover:text-white hover:bg-slate-700/50"}`}><t.icon className="w-4 h-4" />{t.label}</button>))}</div>

      {/* ===================== SCAN CONFIG ===================== */}
      {tab === "scan" && (<Card padding="lg"><CardHeader title="Scan Runtime Config" subtitle="Scanner engine parameters" action={<Radar className="w-5 h-5 text-cyan-400" />} />
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6"><NumField label="ENGINE_VERSION" value={engVer} onChange={setEngVer} hint="Engine version" step="0.01" /><NumField label="TOP_LIMIT" value={topLimit} onChange={setTopLimit} hint="Max symbols to scan" step="1" /><Field label="TIMEFRAME" hint="Scan timeframe"><Select value={timeframe} onChange={setTimeframe} options={[{value:"15m",label:"15m"},{value:"1h",label:"1h"},{value:"4h",label:"4h"}]} /></Field><NumField label="MAX_OPEN_TRADES" value={maxOpenTrades} onChange={setMaxOpenTrades} hint="Max concurrent open trades" step="1" /><BoolField label="ENABLE_SCHEDULER" value={scheduler} onChange={setScheduler} hint="Auto scan" /><BoolField label="ENABLE_MONITOR" value={monitor} onChange={setMonitor} hint="Monitor trades" /></div>
        <SaveRow saving={s2} saved={sv2} onSave={saveScanConfig} onCancel={() => applyConfig(orig)} /></Card>)}

      {/* ===================== SIGNAL CONFIG ===================== */}
      {tab === "signals" && (<Card padding="lg"><CardHeader title="Signal Runtime Config" subtitle="Signal detection & filtering parameters" action={<Crosshair className="w-5 h-5 text-yellow-400" />} />
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6"><NumField label="SCORE_THRESHOLD" value={scoreThreshold} onChange={setScoreThreshold} hint="Min score" step="0.1" /><NumField label="BODY_RATIO_THRESHOLD" value={bodyRatio} onChange={setBodyRatio} hint="Candle body ratio" step="0.01" /><NumField label="VOLUME_MULTIPLIER" value={volMult} onChange={setVolMult} hint="Volume filter" step="0.1" /><NumField label="ATR_RATIO_MIN" value={atrMin} onChange={setAtrMin} hint="Min ATR ratio" step="0.0001" /><NumField label="COOLDOWN_HOURS" value={cooldown} onChange={setCooldown} hint="Hours between signals" step="1" /><NumField label="AI_THRESHOLD" value={aiThreshold} onChange={setAiThreshold} hint="ML probability" step="0.05" /><BoolField label="MTF_ENABLED" value={mtfEnabled} onChange={setMtfEnabled} hint="Multi-timeframe" /></div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
          <div className="p-4 bg-slate-900/30 rounded-lg border border-slate-700/50"><h4 className="text-sm font-semibold text-slate-300 mb-4">DERIVATIVE_CONFIG</h4><div className="space-y-3"><NumField label="bias_scale · 15m" value={derivBias15m} onChange={setDerivBias15m} step="0.1" /><NumField label="bias_scale · 1h" value={derivBias1h} onChange={setDerivBias1h} step="0.1" /><NumField label="bias_scale · 4h" value={derivBias4h} onChange={setDerivBias4h} step="0.1" /><NumField label="pre_buffer" value={derivPreBuffer} onChange={setDerivPreBuffer} step="0.1" /></div></div>
          <div className="p-4 bg-slate-900/30 rounded-lg border border-slate-700/50"><h4 className="text-sm font-semibold text-slate-300 mb-4">RISK_CONFIG</h4><div className="space-y-3"><div className="grid grid-cols-2 gap-3"><NumField label="15m · SL %" value={riskSl15m} onChange={setRiskSl15m} step="0.001" /><NumField label="15m · TP %" value={riskTp15m} onChange={setRiskTp15m} step="0.001" /></div><div className="grid grid-cols-2 gap-3"><NumField label="1h · SL %" value={riskSl1h} onChange={setRiskSl1h} step="0.001" /><NumField label="1h · TP %" value={riskTp1h} onChange={setRiskTp1h} step="0.001" /></div><div className="grid grid-cols-2 gap-3"><NumField label="4h · SL %" value={riskSl4h} onChange={setRiskSl4h} step="0.001" /><NumField label="4h · TP %" value={riskTp4h} onChange={setRiskTp4h} step="0.001" /></div></div></div>
          <div className="p-4 bg-slate-900/30 rounded-lg border border-slate-700/50"><h4 className="text-sm font-semibold text-slate-300 mb-4">PENDING_CONFIG</h4><div className="space-y-3"><BoolField label="Pending Enabled" value={pendEnabled} onChange={setPendEnabled} /><div className="grid grid-cols-2 gap-3"><NumField label="ATR mult · 15m" value={pendAtr15m} onChange={setPendAtr15m} step="0.1" /><NumField label="Expire hrs · 15m" value={pendExp15m} onChange={setPendExp15m} step="1" /></div><div className="grid grid-cols-2 gap-3"><NumField label="ATR mult · 1h" value={pendAtr1h} onChange={setPendAtr1h} step="0.1" /><NumField label="Expire hrs · 1h" value={pendExp1h} onChange={setPendExp1h} step="1" /></div><div className="grid grid-cols-2 gap-3"><NumField label="ATR mult · 4h" value={pendAtr4h} onChange={setPendAtr4h} step="0.1" /><NumField label="Expire hrs · 4h" value={pendExp4h} onChange={setPendExp4h} step="1" /></div></div></div>
        </div>
        <SaveRow saving={s1} saved={sv1} onSave={saveSignalConfig} onCancel={() => applyConfig(orig)} /></Card>)}

      {/* ===================== TRADE FILTER ===================== */}
      {tab === "filter" && otf && (<div className="space-y-4"><Card><div className="flex items-center justify-between mb-4">
        <div className="min-w-0"><h3 className="text-lg font-semibold text-white">Open Trade Filter</h3><p className="text-sm text-slate-400">Kiểm soát điều kiện trước khi mở lệnh</p></div>
        <div className="flex items-center gap-4 flex-shrink-0 ml-4">
          <button onClick={() => updOtf("enabled", !otf.enabled)} className={`relative w-14 h-7 rounded-full transition flex-shrink-0 ${otf.enabled ? "bg-green-500" : "bg-slate-600"}`}><span className={`absolute top-1.5 w-4 h-4 bg-white rounded-full transition-transform ${otf.enabled ? "translate-x-8" : "translate-x-1"}`} /></button>
          <span className={`text-sm font-medium whitespace-nowrap ${otf.enabled ? "text-green-400" : "text-slate-500"}`}>{otf.enabled ? "ACTIVE" : "OFF"}</span>
          <Button variant="primary" size="sm" loading={sOtf} onClick={saveOtf}>{svOtf ? "✅ Saved" : "Save"}</Button>
        </div></div>
        {otfStatus && (<div className="grid grid-cols-4 gap-3 mb-4">{[{ label: "Open Trades", value: otfStatus.open_trades, max: otf.position?.max_concurrent_trades }, { label: "Pending", value: otfStatus.pending_trades }, { label: "Today PnL", value: `${(otfStatus.today?.pnl_pct||0)>=0?"+":""}${(otfStatus.today?.pnl_pct||0).toFixed(2)}%` }, { label: "Loss Streak", value: otfStatus.current_loss_streak }].map((c,i) => (<div key={i} className="p-3 bg-slate-900/50 rounded-lg border border-slate-700"><div className="text-xs text-slate-400">{c.label}</div><div className="text-xl font-bold text-white mt-1">{c.value}{c.max !== undefined && <span className="text-sm text-slate-500 font-normal ml-1">/ {c.max}</span>}</div></div>))}</div>)}
        <div className="space-y-6">
          {/* A. Identity with All toggles */}
          <div className="p-4 bg-slate-900/30 rounded-lg border border-slate-700/50"><h4 className="text-sm font-semibold text-slate-300 mb-3">🎯 A. Identity</h4><div className="space-y-3">
            <MultiRow label="Direction" allItems={["LONG","SHORT"]} selected={otf.identity?.directions} onToggle={v => togOtfArr("identity.directions", v)} onSetAll={v => updOtf("identity.directions", v)} />
            <MultiRow label="Strategies" allItems={["candlestick","breakout","mean_reversion","pullback","trend_following"]} selected={otf.identity?.strategies} onToggle={v => togOtfArr("identity.strategies", v)} onSetAll={v => updOtf("identity.strategies", v)} />
            <MultiRow label="Patterns" allItems={["engulfing","hammer","shooting_star","doji","morning_star","evening_star","harami","marubozu"]} selected={otf.identity?.patterns} onToggle={v => togOtfArr("identity.patterns", v)} onSetAll={v => updOtf("identity.patterns", v)} />
            <MultiRow label="Timeframes" allItems={["15m","1h","4h"]} selected={otf.identity?.timeframes} onToggle={v => togOtfArr("identity.timeframes", v)} onSetAll={v => updOtf("identity.timeframes", v)} />
            <MultiRow label="Regimes" allItems={["BULL","BEAR","SIDEWAYS"]} selected={otf.market_condition?.allowed_regimes} onToggle={v => togOtfArr("market_condition.allowed_regimes", v)} onSetAll={v => updOtf("market_condition.allowed_regimes", v)} />
          </div></div>
          {/* C. Score + D. Position */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="p-4 bg-slate-900/30 rounded-lg border border-slate-700/50"><h4 className="text-sm font-semibold text-slate-300 mb-3">⭐ C. Score Requirements</h4><div className="space-y-3">{[{key:"score.min_overall",label:"Min Score",step:0.5,min:0,max:10},{key:"score.min_ml_prob",label:"Min ML Prob",step:0.05,min:0,max:1},{key:"score.min_trend_score",label:"Min Trend",step:0.1,min:0,max:3},{key:"score.min_mtf_score",label:"Min MTF",step:0.05,min:0,max:1}].map(f => { const keys = f.key.split("."); const val = otf?.[keys[0]]?.[keys[1]] ?? 0; return (<div key={f.key}><label className="block text-xs text-slate-400 mb-1">{f.label}</label><input type="number" step={f.step} min={f.min} max={f.max} value={val} onChange={e => updOtf(f.key, parseFloat(e.target.value))} className="w-full px-2 py-1.5 bg-slate-900 border border-slate-600 rounded text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500" /></div>); })}</div></div>
            <div className="p-4 bg-slate-900/30 rounded-lg border border-slate-700/50"><h4 className="text-sm font-semibold text-slate-300 mb-3">📐 D. Position Management</h4><div className="space-y-3">{[{key:"position.max_concurrent_trades",label:"Max Concurrent",step:1,min:1,max:100},{key:"position.max_per_symbol",label:"Max / Symbol",step:1,min:1,max:10},{key:"position.max_daily_trades",label:"Max Daily Trades",step:1,min:0,max:200},{key:"position.max_daily_loss_pct",label:"Max Daily Loss %",step:0.5,min:0,max:50},{key:"position.pause_after_loss_streak",label:"Pause After Streak",step:1,min:0,max:20}].map(f => { const keys = f.key.split("."); const val = otf?.[keys[0]]?.[keys[1]] ?? 0; return (<div key={f.key}><label className="block text-xs text-slate-400 mb-1">{f.label}</label><input type="number" step={f.step} min={f.min} max={f.max} value={val} onChange={e => updOtf(f.key, parseFloat(e.target.value))} className="w-full px-2 py-1.5 bg-slate-900 border border-slate-600 rounded text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500" /></div>); })}</div></div>
          </div>
          {/* E. Time */}
          <div className="p-4 bg-slate-900/30 rounded-lg border border-slate-700/50"><h4 className="text-sm font-semibold text-slate-300 mb-3">🕐 E. Time Restrictions (UTC+7)</h4><label className="flex items-center gap-2 cursor-pointer mb-3"><input type="checkbox" checked={otf.time?.enabled || false} onChange={e => updOtf("time.enabled", e.target.checked)} className="w-4 h-4 accent-blue-500" /><span className="text-sm text-slate-300">Enable time restriction</span></label>{otf.time?.enabled && (<div className="flex items-center gap-3"><input type="time" value={otf.time?.allowed_hours?.start || "00:00"} onChange={e => updOtf("time.allowed_hours.start", e.target.value)} className="px-2 py-1 bg-slate-900 border border-slate-600 rounded text-sm text-white" /><span className="text-slate-500">→</span><input type="time" value={otf.time?.allowed_hours?.end || "23:59"} onChange={e => updOtf("time.allowed_hours.end", e.target.value)} className="px-2 py-1 bg-slate-900 border border-slate-600 rounded text-sm text-white" /></div>)}</div>
        </div></Card></div>)}

      {/* ===================== PRE-FILL ===================== */}
      {tab === "prefill" && pf && (<div className="space-y-4"><Card><div className="flex items-center justify-between mb-6"><div className="min-w-0"><h3 className="text-lg font-semibold text-white">Pre-Fill Validation</h3><p className="text-sm text-slate-400">Kiểm tra thị trường TRƯỚC khi fill Pending → Signal</p></div><div className="flex items-center gap-4 flex-shrink-0 ml-4"><button onClick={() => updPf("enabled", !pf.enabled)} className={`relative w-14 h-7 rounded-full transition flex-shrink-0 ${pf.enabled ? "bg-green-500" : "bg-slate-600"}`}><span className={`absolute top-1.5 w-4 h-4 bg-white rounded-full transition-transform ${pf.enabled ? "translate-x-8" : "translate-x-1"}`} /></button><span className={`text-sm font-medium whitespace-nowrap ${pf.enabled ? "text-green-400" : "text-slate-500"}`}>{pf.enabled ? "ACTIVE" : "OFF"}</span><Button variant="primary" size="sm" loading={sPf} onClick={savePf}>{svPf ? "✅ Saved" : "Save"}</Button></div></div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* 1. Price Context */}
          <div className="p-4 bg-slate-900/30 rounded-lg border border-slate-700/50">
            <div className="flex items-center gap-3 mb-4"><label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={pf.price_context?.enabled ?? true} onChange={e => updPf("price_context.enabled", e.target.checked)} className="w-4 h-4 accent-blue-500" /><span className="text-sm font-semibold text-slate-300">1. Price Context</span></label><span className="text-xs text-slate-500">Giá di chuyển ngược quá nhiều?</span></div>
            <div className="space-y-3">{[{l:"Max adverse 15m %",p:"price_context.max_adverse_move_pct.15m",s:0.1},{l:"Max adverse 1h %",p:"price_context.max_adverse_move_pct.1h",s:0.1},{l:"Max adverse 4h %",p:"price_context.max_adverse_move_pct.4h",s:0.1}].map(f => { const ks = f.p.split("."); let v = pf; for (const k of ks) v = v?.[k]; return (<div key={f.p}><label className="block text-xs text-slate-400 mb-1">{f.l}</label><input type="number" step={f.s} value={v ?? 0} onChange={e => updPf(f.p, parseFloat(e.target.value))} className="w-full px-2 py-1.5 bg-slate-900 border border-slate-600 rounded text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500" /></div>); })}</div>
          </div>
          {/* 2. Candle Invalidation */}
          <div className="p-4 bg-slate-900/30 rounded-lg border border-slate-700/50">
            <div className="flex items-center gap-3 mb-4"><label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={pf.candle_invalidation?.enabled ?? true} onChange={e => updPf("candle_invalidation.enabled", e.target.checked)} className="w-4 h-4 accent-blue-500" /><span className="text-sm font-semibold text-slate-300">2. Candle Invalidation</span></label><span className="text-xs text-slate-500">Nến body lớn ngược chiều?</span></div>
            <div className="space-y-3"><div><label className="block text-xs text-slate-400 mb-1">Adverse body ATR mult</label><input type="number" step={0.1} value={pf.candle_invalidation?.adverse_body_atr_mult ?? 0} onChange={e => updPf("candle_invalidation.adverse_body_atr_mult", parseFloat(e.target.value))} className="w-full px-2 py-1.5 bg-slate-900 border border-slate-600 rounded text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500" /></div></div>
          </div>
          {/* 3. Momentum Check */}
          <div className="p-4 bg-slate-900/30 rounded-lg border border-slate-700/50">
            <div className="flex items-center gap-3 mb-4"><label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={pf.momentum_check?.enabled ?? true} onChange={e => updPf("momentum_check.enabled", e.target.checked)} className="w-4 h-4 accent-blue-500" /><span className="text-sm font-semibold text-slate-300">3. Momentum Check</span></label><span className="text-xs text-slate-500">RSI vẫn hỗ trợ direction?</span></div>
            <div className="space-y-3">{[{l:"Reject LONG if RSI above",p:"momentum_check.rsi_reject_long_above",s:1},{l:"Reject SHORT if RSI below",p:"momentum_check.rsi_reject_short_below",s:1}].map(f => { const ks = f.p.split("."); let v = pf; for (const k of ks) v = v?.[k]; return (<div key={f.p}><label className="block text-xs text-slate-400 mb-1">{f.l}</label><input type="number" step={f.s} value={v ?? 0} onChange={e => updPf(f.p, parseFloat(e.target.value))} className="w-full px-2 py-1.5 bg-slate-900 border border-slate-600 rounded text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500" /></div>); })}</div>
          </div>
          {/* 4. Volatility Guard */}
          <div className="p-4 bg-slate-900/30 rounded-lg border border-slate-700/50">
            <div className="flex items-center gap-3 mb-4"><label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={pf.volatility_guard?.enabled ?? true} onChange={e => updPf("volatility_guard.enabled", e.target.checked)} className="w-4 h-4 accent-blue-500" /><span className="text-sm font-semibold text-slate-300">4. Volatility Guard</span></label><span className="text-xs text-slate-500">ATR spike so với lúc scan?</span></div>
            <div className="space-y-3"><div><label className="block text-xs text-slate-400 mb-1">ATR spike multiplier</label><input type="number" step={0.1} value={pf.volatility_guard?.atr_spike_multiplier ?? 0} onChange={e => updPf("volatility_guard.atr_spike_multiplier", parseFloat(e.target.value))} className="w-full px-2 py-1.5 bg-slate-900 border border-slate-600 rounded text-sm text-white font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500" /></div></div>
          </div>
          {/* 5. Regime Check */}
          <div className="p-4 bg-slate-900/30 rounded-lg border border-slate-700/50 lg:col-span-2">
            <div className="flex items-center gap-3"><label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={pf.regime_check?.enabled ?? true} onChange={e => updPf("regime_check.enabled", e.target.checked)} className="w-4 h-4 accent-blue-500" /><span className="text-sm font-semibold text-slate-300">5. Regime Check</span></label><span className="text-xs text-slate-500">Regime flip → conflict direction → reject</span></div>
          </div>
        </div>
        <div className="flex justify-end pt-4"><Button variant="primary" loading={sPf} onClick={savePf}>{svPf ? "✅ Saved!" : "💾 Save Prefill Config"}</Button></div></Card></div>)}

      {/* ===================== STRATEGIES ===================== */}
      {tab === "strats" && (()=>{ const STRAT_DESC = { candlestick: "Mô hình nến: Engulfing, Hammer, Star...", breakout: "Phá vỡ swing high/low + volume surge", mean_reversion: "RSI extreme + BB touch → đảo chiều", pullback: "Trend mạnh → giá về EMA50", trend_following: "EMA crossover + volume confirm" }; return (<Card><div className="flex items-center justify-between mb-4"><div><h3 className="text-lg font-semibold text-white">Strategy Management</h3><p className="text-sm text-slate-400">Bật/tắt chiến thuật giao dịch</p></div><Button variant="primary" size="sm" loading={sSt} onClick={saveStrats}>{svSt ? "✅ Saved" : "Save"}</Button></div><div className="space-y-3">{stratsList.map(s => (<div key={s.name} className="flex items-center p-4 bg-slate-900/30 rounded-xl border border-slate-700"><button onClick={() => toggleStrat(s.name)} className={`relative w-12 h-7 rounded-full transition flex-shrink-0 ${s.active ? "bg-green-500" : "bg-slate-600"}`}><span className={`absolute top-1.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${s.active ? "translate-x-6" : "translate-x-1"}`} /></button><div className="ml-6 min-w-0"><div className="flex items-center gap-3"><span className="font-medium text-white capitalize">{s.name.replace(/_/g, " ")}</span><span className={`text-xs flex-shrink-0 ${s.active ? "text-emerald-400" : "text-slate-500"}`}>{s.active ? "● Active" : "○ Inactive"}</span></div><div className="text-xs text-slate-500 mt-0.5">{STRAT_DESC[s.name] || ""}</div></div></div>))}</div></Card>); })()}

      {/* ===================== LIVE TRADING ===================== */}
      {tab === "live" && (<Card padding="lg"><CardHeader title="Live Trading Config" subtitle="Limit order & execution settings" action={<Activity className="w-5 h-5 text-green-400" />} />
        <div className="p-4 bg-slate-900/30 rounded-lg border border-slate-700/50">
          <h4 className="text-sm font-semibold text-slate-300 mb-4">LIMIT_ORDER_CONFIG</h4>
          <div className="space-y-3">
            <BoolField label="Limit Order Enabled" value={limitEnabled} onChange={setLimitEnabled} />
            <div className="grid grid-cols-2 gap-3"><NumField label="entry_reprice_pct · 15m" value={limitRp15m} onChange={setLimitRp15m} step="0.001" /><div /></div>
            <div className="grid grid-cols-2 gap-3"><NumField label="entry_reprice_pct · 1h" value={limitRp1h} onChange={setLimitRp1h} step="0.001" /><div /></div>
            <div className="grid grid-cols-2 gap-3"><NumField label="entry_reprice_pct · 4h" value={limitRp4h} onChange={setLimitRp4h} step="0.001" /><div /></div>
          </div>
        </div>
        <SaveRow saving={sLt} saved={svLt} onSave={saveLiveTrading} onCancel={() => applyConfig(orig)} /></Card>)}

      {/* ===================== SYSTEM ===================== */}
      {tab === "system" && (<div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card padding="lg"><h3 className="text-lg font-semibold text-white mb-4">🔄 Trading Mode</h3><div className="flex gap-3 mb-4">{["PAPER","TESTNET","LIVE"].map(m => { const colors = { PAPER: "bg-blue-900/30 border-blue-700 text-blue-300", TESTNET: "bg-yellow-900/30 border-yellow-700 text-yellow-300", LIVE: "bg-red-900/30 border-red-700 text-red-300" }; const current = modeInfo?.mode === m; return (<button key={m} onClick={() => switchMode(m)} className={`flex-1 py-3 rounded-lg border font-medium text-sm transition ${current ? colors[m] : "bg-slate-700 border-slate-600 text-slate-300 hover:bg-slate-600"}`}>{m === "PAPER" ? "📋 PAPER" : m === "TESTNET" ? "🧪 TESTNET" : "💰 LIVE"}</button>); })}</div>{modeInfo && (<div className="p-3 bg-slate-900/30 rounded-lg border border-slate-700 text-sm text-slate-300">{modeInfo.description}</div>)}</Card>
        <Card padding="lg"><h3 className="text-lg font-semibold text-white mb-4">📡 Price Feed</h3>{feedInfo ? (<div className="grid grid-cols-2 md:grid-cols-4 gap-4">{[{ label: "Status", value: feedInfo.healthy ? "🟢 Healthy" : "🔴 Unhealthy" }, { label: "Mode", value: (feedInfo.mode || "").toUpperCase() }, { label: "Symbols", value: feedInfo.symbols_count }, { label: "Last Update", value: feedInfo.last_update_ago_s != null ? `${feedInfo.last_update_ago_s}s ago` : "—" }].map((item, i) => (<div key={i} className="bg-slate-900/30 rounded-lg p-3 text-center"><div className="text-xs text-slate-400">{item.label}</div><div className="text-white font-medium mt-1">{item.value}</div></div>))}</div>) : <div className="text-slate-400 text-sm">Loading...</div>}</Card>
        <Card padding="lg"><div className="flex items-center justify-between mb-4"><h3 className="text-lg font-semibold text-white">🤖 ML Model</h3><Button variant="secondary" size="sm" loading={retraining} onClick={retrain}>🔁 Retrain</Button></div>{mlInfo && !mlInfo.error ? (<div className="space-y-3"><div className="grid grid-cols-3 gap-3">{[{ label: "Signals (30d)", value: mlInfo.total_signals }, { label: "AUC", value: mlInfo.auc?.toFixed(4) }, { label: "Win Rate", value: `${(mlInfo.overall_winrate*100).toFixed(1)}%` }].map((item, i) => (<div key={i} className="bg-slate-900/30 rounded-lg p-3 text-center"><div className="text-xs text-slate-400">{item.label}</div><div className="text-white font-medium mt-1">{item.value}</div></div>))}</div>{mlInfo.threshold_analysis?.length > 0 && (<div className="overflow-x-auto"><table className="w-full text-xs"><thead><tr className="text-slate-400 border-b border-slate-700"><th className="text-left py-1">Threshold</th><th className="text-right py-1">Signals</th><th className="text-right py-1">Win Rate</th><th className="text-right py-1">Avg Return</th></tr></thead><tbody>{mlInfo.threshold_analysis.map(t => (<tr key={t.threshold} className="border-b border-slate-800"><td className="py-1 text-white">≥{t.threshold}</td><td className="py-1 text-right">{t.n_signals}</td><td className={`py-1 text-right ${t.winrate>=0.55?"text-green-400":"text-gray-300"}`}>{(t.winrate*100).toFixed(1)}%</td><td className={`py-1 text-right ${t.avg_return>0?"text-green-400":"text-red-400"}`}>{t.avg_return>0?"+":""}{t.avg_return?.toFixed(2)}%</td></tr>))}</tbody></table></div>)}</div>) : <div className="text-slate-400 text-sm">{mlInfo?.error || "Loading..."}</div>}{retainResult && (<div className={`mt-3 p-3 rounded-lg border text-sm ${retainResult.status === "success" ? "bg-green-900/30 border-green-700 text-green-300" : "bg-slate-700 border-slate-600 text-slate-300"}`}>{retainResult.status === "success" && `✅ AUC: ${retainResult.avg_auc?.toFixed(4)} | Samples: ${retainResult.train_size}`}{retainResult.status === "skipped" && `⏭ ${retainResult.reason}`}{retainResult.status === "rejected" && `❌ ${retainResult.reason}`}</div>)}</Card>
        {/* Theme */}
        <Card padding="lg"><h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2"><Palette className="w-5 h-5 text-purple-400" /> Theme</h3><div className="space-y-3">{[
          { id: "dark", name: "Dark Mode", desc: "Default dark theme — Slate + Indigo", colors: ["#1e293b","#334155","#6366f1","#10b981","#ef4444"] },
          { id: "trading", name: "Trading Pro", desc: "Bloomberg / TradingView style — Pro trading terminal", colors: ["#0a0e17","#111827","#2196f3","#00c853","#ff1744"] },
          { id: "light", name: "Light Gold", desc: "Nền sáng ấm — tông vàng chủ đạo, premium finance", colors: ["#faf8f4","#f5f0e8","#b8860b","#16a34a","#dc2626"] },
        ].map(t => (<button key={t.id} onClick={() => saveTheme(t.id)} className={`w-full flex items-center gap-4 p-4 rounded-lg border text-left transition ${storeTheme === t.id ? "border-indigo-500 bg-indigo-500/10" : "border-slate-700 bg-slate-900/30 hover:border-slate-600"}`}><div className="flex-shrink-0"><div className={`w-5 h-5 rounded-full border-2 ${storeTheme === t.id ? "border-indigo-500 bg-indigo-500" : "border-slate-600"}`} /><div className="flex gap-0.5 mt-2">{t.colors.map((c,i) => <div key={i} className="w-3 h-3 rounded-sm" style={{backgroundColor:c}} />)}</div></div><div><div className="text-sm font-medium text-white">{t.name}</div><div className="text-xs text-slate-500">{t.desc}</div></div></button>))}</div></Card>
        {/* Admin */}
        <Card padding="lg"><h3 className="text-lg font-semibold text-white mb-4">⚡ Admin Actions</h3><div className="flex flex-wrap gap-3"><Button variant="secondary" onClick={async () => { const r = await fetch("/api/admin/cancel-all-pending",{method:"POST"}).then(r=>r.json()); toast.success(`Cancelled ${r.cancelled} pending`); }}>🚫 Cancel All Pending</Button><Button variant="secondary" onClick={async () => { await fetch("/api/admin/refresh-views",{method:"POST"}); toast.success("Views refreshed"); }}>♻️ Refresh DB Views</Button></div></Card>
      </div>)}

      {/* ===================== CONNECTION ===================== */}
      {tab === "conn" && (<Card padding="lg"><CardHeader title="Connection Settings" subtitle="Cấu hình kết nối — mặc định dùng .env" action={<Plug className="w-5 h-5 text-orange-400" />} />
        {/* Override toggle */}
        <div className="flex items-center gap-4 p-4 mb-6 rounded-lg border border-slate-700/50 bg-slate-900/30">
          <button onClick={() => setConnOverride(!connOverride)} className={`relative w-14 h-7 rounded-full transition flex-shrink-0 ${connOverride ? "bg-orange-500" : "bg-slate-600"}`}><span className={`absolute top-1.5 w-4 h-4 bg-white rounded-full transition-transform ${connOverride ? "translate-x-8" : "translate-x-1"}`} /></button>
          <div className="min-w-0">
            <div className="text-sm font-medium text-white">{connOverride ? "Override Active — dùng giá trị bên dưới" : "Using .env — mặc định từ environment"}</div>
            <div className="text-xs text-slate-500 mt-0.5">{connOverride ? "Backend sẽ ưu tiên đọc từ app_config thay vì .env (cần backend hỗ trợ)" : "Tất cả kết nối đang đọc từ file .env hoặc biến môi trường"}</div>
          </div>
        </div>
        {/* Fields */}
        <div className={`grid grid-cols-1 lg:grid-cols-2 gap-6 ${!connOverride ? "opacity-40 pointer-events-none" : ""}`}>
          <TextField label="DATABASE_URL" value={connDb} onChange={setConnDb} hint="PostgreSQL connection string" type="password" placeholder="postgresql://..." />
          <TextField label="BINANCE_API_KEY" value={connBnKey} onChange={setConnBnKey} hint="Binance Futures API Key" type="password" />
          <TextField label="BINANCE_API_SECRET" value={connBnSecret} onChange={setConnBnSecret} hint="Binance Futures API Secret" type="password" />
          <TextField label="TELEGRAM_BOT_TOKEN" value={connTgToken} onChange={setConnTgToken} hint="Telegram bot token" type="password" />
          <TextField label="GROQ_API_KEY" value={connGroq} onChange={setConnGroq} hint="Groq LLM API key" type="password" />
          <TextField label="GEMINI_API_KEY" value={connGemini} onChange={setConnGemini} hint="Google Gemini API key (failover)" type="password" />
        </div>
        {!connOverride && (<div className="mt-4 p-3 rounded-lg bg-blue-500/10 border border-blue-500/20 text-xs text-blue-300">ℹ️ Bật Override để nhập giá trị thay thế .env. Backend cần đọc CONNECTION_OVERRIDE=true từ app_config để kích hoạt.</div>)}
        <SaveRow saving={sConn} saved={svConn} onSave={saveConn} onCancel={() => applyConfig(orig)} /></Card>)}

      {/* ===================== API KEYS ===================== */}
      {tab === "apikey" && (<Card padding="lg"><CardHeader title="API Keys" subtitle="Dashboard authentication key" action={<KeyRound className="w-5 h-5 text-amber-400" />} />
        <div className="max-w-lg">
          <TextField label="DASHBOARD_API_KEY" value={dashApiKey} onChange={setDashApiKey} hint="Used in X-API-Key header for all dashboard API calls" placeholder="Enter API key..." />
        </div>
        <SaveRow saving={sKey} saved={svKey} onSave={saveApiKey} onCancel={() => applyConfig(orig)} /></Card>)}
    </div>
  );
}
