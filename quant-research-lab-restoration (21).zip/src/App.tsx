// @ts-nocheck
import { HashRouter, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { useIsMobile } from './hooks/useIsMobile';
import { Layout } from './components/layout/Layout';
import { MobileLayout } from './components/layout/MobileLayout';
import { Dashboard } from './pages/DashboardPage';
import { Research } from './pages/ResearchPage';
import { Signals } from './pages/SignalsPage';
import { EdgeDiscovery } from './pages/EdgeDiscoveryPage';
import { Indicators } from './pages/IndicatorsPage';
import { PendingSignalsPage as PendingSignals } from './pages/PendingSignalsPage';
import { AccountPage } from './pages/AccountPage';
import { ManualBehaviorPage } from './pages/ManualBehaviorPage';
import { ScanTestPage } from './pages/ScanTestPage';
import { QueryLab } from './pages/QueryLabPage';
import { SettingsPage } from './pages/SettingsPage';
import { MarketPage, EnginePage, BlockedPage } from './pages/PlaceholderPages';
import { SimulationPage } from './pages/SimulationPage';

export default function App() {
  const isMobile = useIsMobile();
  const LayoutWrapper = isMobile ? MobileLayout : Layout;

  return (
    <HashRouter>
      <Toaster position="top-right" toastOptions={{ style: { background: '#1e293b', color: '#e2e8f0', border: '1px solid #334155' } }} />
      <LayoutWrapper>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/research" element={<Research />} />
          <Route path="/market" element={<MarketPage />} />
          <Route path="/signals" element={<Signals />} />
          <Route path="/edge-discovery" element={<EdgeDiscovery />} />
          <Route path="/indicators" element={<Indicators />} />
          <Route path="/pending-signals" element={<PendingSignals />} />
          <Route path="/account" element={<AccountPage />} />
          <Route path="/manual-behavior" element={<ManualBehaviorPage />} />
          <Route path="/engine" element={<EnginePage />} />
          <Route path="/blocked" element={<BlockedPage />} />
          <Route path="/scan-test" element={<ScanTestPage />} />
          <Route path="/simulation" element={<SimulationPage />} />
          <Route path="/query-lab" element={<QueryLab />} />
          <Route path="/settings" element={<SettingsPage />} />
        </Routes>
      </LayoutWrapper>
    </HashRouter>
  );
}
